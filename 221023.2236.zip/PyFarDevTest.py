import colorama
from colorama import Fore,Style,Back
colorama.init(autoreset=True)
print(Fore.CYAN+"© PyOSes Pre-release")
import time
time.sleep(2)
print(Fore.MAGENTA+"PyFar version:")
time.sleep(1)
print(Fore.LIGHTRED_EX+"Dev Preview Build 221023.2236")
time.sleep(6)
import random
import datetime
print("Loading...")
time.sleep(2)
print(Fore.RED+"Finding errors...")
time.sleep(2)
print(Fore.BLUE+"No errors!")
time.sleep(1)
print(Fore.LIGHTCYAN_EX+"Loading library...")
time.sleep(3)
print(Fore.LIGHTYELLOW_EX+"Preparing imports...")
time.sleep(2)
print(Fore.GREEN+"Getting finished...")
time.sleep(3)
print(Fore.MAGENTA+"Preparing to start running...")
time.sleep(5)
print(Fore.LIGHTRED_EX+"Finished!")
time.sleep(2)
print("Please wait...")
time.sleep(0.5)
for i in range(5):
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
    print("                                                                                            ")
    time.sleep(0.1)
print(Fore.GREEN+"To proof that you got access from PyOSes to use this pre-release, enter the correct pre-release username.")
time.sleep(3)
username=str(input("Enter the username to use this Dev build:"))
while True:
    def verifyidentity(username):
        if username == "devtest":
            return "devtest"
        else:
            return "usernotfound"
    identity=verifyidentity
    if username == "devtest":
        print("Welcome Developer test! Preparing.....Please wait patiently!")
        time.sleep(5)
        print("_")
        time.sleep(0.5)
        print(" ")
        print("_")
        time.sleep(0.5)
        print(" ")
        print("_")
        time.sleep(0.5)
        print(" ")
        print("_")
        time.sleep(0.5)
        print(" ")
        print("_")
        time.sleep(0.5)
        print(" ")
        time.sleep(2)
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print(Fore.RED+"               Republic of Gamers           ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait...")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait...")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait...")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait.")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait..")
        time.sleep(0.5)
        print("Booting BIOS UEFI please wait...")
        time.sleep(5)
        print("American Megatrends")
        time.sleep(6)
        print("Boot options:")
        time.sleep(1.5)
        print("Boot option 1: Windows 11 Dev Build 22504.1010")
        time.sleep(1.5)
        print("Boot option two:")
        installusb = str(input(
            "SanDisk 516GB RCs283097 (USB Mass Storage Device.Is this the right boot disk/USB to boot installer?  Yes/No  "))
        time.sleep(1)
        print("Loading...")
        time.sleep(0.5)
        print("Loading...")
        time.sleep(0.5)
        print("Loading...")
        time.sleep(0.5)
        print("Loading...")
        time.sleep(5)
        print("Settings changed!")
        time.sleep(3)
        print("Windows will have to restart to apply BIOS setting to the OS.")
        time.sleep(0.5)
        print("Restarting in 3...")
        time.sleep(0.5)
        print("Restarting in 2...")
        time.sleep(0.5)
        print("Restarting in 1...")
        time.sleep(1)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")

        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        print(Fore.CYAN+"                .")
        print(Fore.CYAN+"           .           .                ")
        print(Fore.CYAN+"         .               .               ")
        print(Fore.CYAN+"        .                 .              ")
        print(Fore.CYAN+"        .                 .                ")
        print(Fore.CYAN+"        .                 .                 ")
        print(Fore.CYAN+"         .              .                     ")
        print(Fore.CYAN+"               .                          ")
        print("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")

        print("This is PyFar™ official installation.")
        time.sleep(5)
        print("Please choose your installation disk")
        time.sleep(0.5)
        disk = str(input("Enter your disk installation path:"))
        time.sleep(0.7)
        iso = str(input("Please choose you installation ISO image:"))
        time.sleep(5)
        print("Copying installation files    0%")
        time.sleep(5)
        print("Copying installation files    100%")
        time.sleep(0.5)
        print("Getting files ready for installation   0%")
        time.sleep(3)
        print("Getting files ready for installation   100%")
        time.sleep(0.5)
        print("Installing features   0%")
        time.sleep(10)
        print("Installing features   100%")
        time.sleep(0.5)
        print("Installing updates   0%")
        time.sleep(15)
        print("Installing updates     100%")
        time.sleep(0.5)
        print("Getting finished         0%")
        time.sleep(5)
        print("Getting finished         100%")
        time.sleep(5)
        print("PyFar™ have to restart to apply the settings.")
        time.sleep(2)
        print("Restarting in 3")
        time.sleep(2)
        print("Restarting in 2")
        time.sleep(2)
        print("Restarting in 1")
        time.sleep(0.7)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print("                                                ")
        print(Fore.CYAN+"                 .")
        print(Fore.CYAN+"           .           .                ")
        print(Fore.CYAN+"         .               .               ")
        print(Fore.CYAN+"        .                 .              ")
        print(Fore.CYAN+"        .                 .                ")
        print(Fore.CYAN+"        .                 .                 ")
        print(Fore.CYAN+"         .              .                     ")
        print(Fore.CYAN+"               .                          ")
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(0.7)
        print("Loading administrator settings......")
        time.sleep(2)
        print("Hello! Welcome to PyFar™!")
        time.sleep(1)
        print("©2022 PyOSes Corporation")
        print("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(2)
        print("But, before installing, activate PyFar with your product key!")
        prokey: str = str(input("Please enter your product key:"))
        if prokey != "prokey":
            print("Your product key is invalid. Please get a new one.")
            time.sleep(1000000)
        else:
            print("Thank you for choosing PyOSes! We are activating your PyFar™ installation.")
            time.sleep(2)
            print("Please wait.")
            time.sleep(0.5)
            print("Please wait..")
            time.sleep(0.5)
            print("Please wait...")
            time.sleep(0.5)
            print("Please wait.")
            time.sleep(0.5)
            print("Please wait..")
            time.sleep(0.5)
            print("Please wait...")
            time.sleep(0.5)
            print("Please wait.")
            time.sleep(0.5)
            print("Please wait..")
            time.sleep(0.5)
            print("Please wait...")
            time.sleep(5)
            print("Finished!")
            time.sleep(2)
        hwrr = str(input("Please enter a computer ID:"))
        print(hwrr)
        time.sleep(1)
        print("We are applying the ID to your computer.")
        time.sleep(0.5)
        print("We are applying the ID to your computer..")
        time.sleep(0.5)
        print("We are applying the ID to your computer...")
        time.sleep(0.5)
        print("We are applying the ID to your computer.")
        time.sleep(0.5)
        print("We are applying the ID to your computer..")
        time.sleep(0.5)
        print("We are applying the ID to your computer...")
        time.sleep(0.5)
        print("We are applying the ID to your computer.")
        time.sleep(0.5)
        print("We are applying the ID to your computer..")
        time.sleep(0.5)
        print("We are applying the ID to your computer...")
        time.sleep(3)
        print("Your computer have to restart to complete applying.")
        dywtr = str(input("Enter 'Restart now' to restart."))
        if dywtr == "Restart now":
            print("Preparing to restart.....")
            time.sleep(3)
            print("Shutting down")
            time.sleep(1)
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
            print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        print(Fore.CYAN+"                .")
        print(Fore.CYAN+"           .           .                ")
        print(Fore.CYAN+"         .               .               ")
        print(Fore.CYAN+"        .                 .              ")
        print(Fore.CYAN+"        .                 .                ")
        print(Fore.CYAN+"        .                 .                 ")
        print(Fore.CYAN+"         .              .                     ")
        print(Fore.CYAN+"                 .                          ")
        print("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("Checking for updates.....")
        print("This may take up to 2 minutes")
        xeuk = random.randint(5, 11)
        time.sleep(xeuk)
        innow = str(input("Enter 'install now' to install   "))
        time.sleep(1)
        print("Please wait...")
        time.sleep(3)
        for i in range(1, 20):
            print("                           ")
            print("                           ")
            print("                           ")
            print("                           ")

        time.sleep(2)
        print("License terms")
        time.sleep(1)
        print("                           ")
        print("                           ")
        print("                           ")
        print("                           ")
        print("PyOSES PRE-RELEASE SOFTWARE LICENSE TERMS")
        print("                           ")
        print("PRE-RELEASE PYFAR™ OPERATING SYSTEM")
        print("                           ")
        print("IF YOU LIVE IN(OR IF A BUSINESS, YOUR PRINCIPAL PLACE")
        print("OF BUSINESS IS IN) THE UNITED STATES, SECTION 1 OF")
        print("THE ADDITIONAL TERMS CONTAINS A BINDING")
        print("ARBITRATION CLAUSE AND CLASS ACTION WAVIER. IT")
        print("AFFECTS YOUR RIGHTS TO RESOLVE A DISPUTE WITH")
        print("PYOSES. PLEASE READ IT.")
        time.sleep(1)
        termacc = str(input("By installing, you agree to the terms and license.Do you agree? Yes/No  "))
        time.sleep(0.5)
        print("Please wait...")
        time.sleep(2)
        cor = str(input("Is Taiwan the right country/region for you? Yes/No  "))
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(3)
        print("Finished!")
        time.sleep(2)
        lang = str(input("Is US the right language for you? Yes/No  "))
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(3)
        print("Finished!")
        time.sleep(2)
        kim = str(input("Is Chinese Traditional(Microsoft Array) the right keyboard layout for you? Yes/No  "))
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(3)
        print("Finished!")
        time.sleep(1)
        akim = str(input("Do you want to add another keyboard layout? Yes/No  "))
        wiakim = str(input("Which other keyboard layout do you want?  "))
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(0.5)
        print("Applying.")
        time.sleep(0.5)
        print("Applying..")
        time.sleep(0.5)
        print("Applying...")
        time.sleep(3)
        print("Finished!")
        time.sleep(4)
        print("Please wait......")
        time.sleep(5)
        print("PyFar™ have to restart to apply the settings.")
        time.sleep(2)
        print("Restarting in 3")
        time.sleep(2)
        print("Restarting in 2")
        time.sleep(2)
        print("Restarting in 1")
        time.sleep(0.7)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        print(Fore.CYAN+"                 .")
        print(Fore.CYAN+"           .           .                ")
        print(Fore.CYAN+"         .               .               ")
        print(Fore.CYAN+"        .                 .              ")
        print(Fore.CYAN+"        .                 .                ")
        print(Fore.CYAN+"        .                 .                 ")
        print(Fore.CYAN+"         .              .                     ")
        print(Fore.CYAN+"                 .                          ")
        time.sleep(2)
        print("""
        
────────────────────────────────────────────────────────────────────────────────────
─██████████████─████████──████████─██████████████─██████████████─████████████████───
─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████░░██─████░░██──██░░████─██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░██──██░░██───██░░░░██░░░░██───██░░██─────────██░░██──██░░██─██░░██────██░░██───
─██░░██████░░██───████░░░░░░████───██░░██████████─██░░██████░░██─██░░████████░░██───
─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
─██░░██████████───────██░░██───────██░░██████████─██░░██████░░██─██░░██████░░████───
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██─────
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░██████─
─██░░██───────────────██░░██───────██░░██─────────██░░██──██░░██─██░░██──██░░░░░░██─
─██████───────────────██████───────██████─────────██████──██████─██████──██████████─
────────────────────────────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────────────────────
─██████████████─██████████████─██████████████─██████──██████─██████████████─
─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─
─██░░██████████─██░░██████████─██████░░██████─██░░██──██░░██─██░░██████░░██─
─██░░██─────────██░░██─────────────██░░██─────██░░██──██░░██─██░░██──██░░██─
─██░░██████████─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████░░██─
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░██──██░░██─██░░░░░░░░░░██─
─██████████░░██─██░░██████████─────██░░██─────██░░██──██░░██─██░░██████████─
─────────██░░██─██░░██─────────────██░░██─────██░░██──██░░██─██░░██─────────
─██████████░░██─██░░██████████─────██░░██─────██░░██████░░██─██░░██─────────
─██░░░░░░░░░░██─██░░░░░░░░░░██─────██░░██─────██░░░░░░░░░░██─██░░██─────────
─██████████████─██████████████─────██████─────██████████████─██████─────────
────────────────────────────────────────────────────────────────────────────
        
        
        
        """)
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(3)
        for i in range(4):
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
        print("Let's finish setting up your device!")
        for i in range(2):
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
            time.sleep(0.1)
            print("                                                                                            ")
        time.sleep(3)
        print("First, enter your PyOS account!")
        time.sleep(1)
        print(Fore.BLUE+"Logging in is not necessary but it's better because you can backup your files and use more features!")
        time.sleep(1)
        print(Fore.MAGENTA+"Don't have one?")
        time.sleep(0.5)
        print(Fore.CYAN+"Create an account!")
        time.sleep(2)
        haact=str(input("Do you have an account? Yes/No  "))
        print(Fore.YELLOW+"Please wait......")
        time.sleep(2)
        if haact == "No":
            print(Fore.RED+"Detecting browser...")
            import webbrowser
            webbrowser.open_new_tab("https://tiny.one/pyoses-register")
            time.sleep(10)
            print("A secret 6-digit log in code should have been given to you after registration.")
            lisc=str(input("Enter your secret log in code:"))
            if lisc=="BQ362E":
                print("Match!")
                time.sleep(2)
            else:
                print("Please register again")
        if haact == "Yes":
            print(Fore.GREEN+"You need to enter your email and password in order to log in.")
            email=str(input(Fore.YELLOW+"Email:"))
            epps=str(input(Fore.MAGENTA+"Password:"))
            print("Password correct!")
            time.sleep(2)
        print(Fore.RED+"Log in complete!")
        print("PyFar™ have to restart to apply your account.")
        time.sleep(2)
        print("Restarting in 3")
        time.sleep(2)
        print("Restarting in 2")
        time.sleep(2)
        print("Restarting in 1")
        time.sleep(0.7)
        print("Preparing to restart.....")
        time.sleep(3)
        print("Shutting down")
        time.sleep(1)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print(Fore.RED+"               Republic of Gamers           ")
        time.sleep(3)
        print(Fore.CYAN+"                 .")
        print(Fore.CYAN+"           .           .                ")
        print(Fore.CYAN+"         .               .               ")
        print(Fore.CYAN+"        .                 .              ")
        print(Fore.CYAN+"        .                 .                ")
        print(Fore.CYAN+"        .                 .                 ")
        print(Fore.CYAN+"         .              .                     ")
        print(Fore.CYAN+"               .                          ")
        time.sleep(5)
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        print("                                                              ")
        time.sleep(5)
        print("Hi!")
        time.sleep(2)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(0.5)
        print("Getting things ready for you.")
        time.sleep(0.5)
        print("Getting things ready for you..")
        time.sleep(0.5)
        print("Getting things ready for you...")
        time.sleep(5)
        print("Checking registry settings.....")
        time.sleep(2)
        print("Now, What's new?")
        time.sleep(2)
        print("Let's check out new things in this new OS!")
        time.sleep(5)
        print("More codes available")
        time.sleep(4)
        print(
            "In PyFar™, more terminal codes and Python support etc. is available. This is a great choice for programmers to use.")
        time.sleep(4)
        print("No more MS-DOS")
        time.sleep(4)
        print(
            "In this edition, it in Python! But not like MS-DOS of Microsoft, it is just running on Python. Don't worry, it'll work as normal and even faster.")
        time.sleep(4)
        print("'PyFar'")
        time.sleep(4)
        print(
            "'PyFar', special name, huh? Yep! There's a meaning behind it!")
        time.sleep(2)
        print("'PyFar' actually means: 'By far', the most powerful operating system.")
        time.sleep(4)
        print("And more features that you can find out later!")
        time.sleep(5)
        print("Please wait...")
        time.sleep(2)
        print("Loading operating system Python code....")
        time.sleep(8)
        print("Almost there.")
        time.sleep(3)
        print("Please wait while Kernel is starting Local Session Manager......")
        time.sleep(6)
        vcpwd = int(input("Enter password:"))
        if vcpwd == 20130714:
            tday=datetime.date.today()
            if tday.isoweekday == 1:
                wd="Monday"
            elif tday.isoweekday == 2:
                wd="Tuesday"
            elif tday.isoweekday == 3:
                wd="Wednesday"
            elif tday.isoweekday == 4:
                wd="Thursday"
            elif tday.isoweekday == 5:
                wd="Friday"
            elif tday.isoweekday == 6:
                wd="Saturday"
            elif tday.isoweekday == 7:
                wd="Sunday"
            else:
                print("PyFar Error@loading weekday.")
                print("Report problem at the 阿塊 Discord server.")
                wd="ERROR"
            
            print(Back.LIGHTYELLOW_EX+"Welcome")
            time.sleep(0.5)
            print(Fore.CYAN+"                .")
            print(Fore.CYAN+"           .           .                ")
            print(Fore.CYAN+"         .               .               ")
            print(Fore.CYAN+"        .                 .              ")
            print(Fore.CYAN+"        .                 .                ")
            print(Fore.CYAN+"        .                 .                 ")
            print(Fore.CYAN+"         .              .                     ")
            print(Fore.CYAN+"               .                          ")
            print("""
░██╗░░░░░░░██╗███████╗██╗░░░░░░█████╗░░█████╗░███╗░░░███╗███████╗
░██║░░██╗░░██║██╔════╝██║░░░░░██╔══██╗██╔══██╗████╗░████║██╔════╝
░╚██╗████╗██╔╝█████╗░░██║░░░░░██║░░╚═╝██║░░██║██╔████╔██║█████╗░░
░░████╔═████║░██╔══╝░░██║░░░░░██║░░██╗██║░░██║██║╚██╔╝██║██╔══╝░░
░░╚██╔╝░╚██╔╝░███████╗███████╗╚█████╔╝╚█████╔╝██║░╚═╝░██║███████╗
░░░╚═╝░░░╚═╝░░╚══════╝╚══════╝░╚════╝░░╚════╝░╚═╝░░░░░╚═╝╚══════╝

██████╗░░█████╗░░█████╗░██╗░░██╗  ████████╗░█████╗░
██╔══██╗██╔══██╗██╔══██╗██║░██╔╝  ╚══██╔══╝██╔══██╗
██████╦╝███████║██║░░╚═╝█████═╝░  ░░░██║░░░██║░░██║
██╔══██╗██╔══██║██║░░██╗██╔═██╗░  ░░░██║░░░██║░░██║
██████╦╝██║░░██║╚█████╔╝██║░╚██╗  ░░░██║░░░╚█████╔╝
╚═════╝░╚═╝░░╚═╝░╚════╝░╚═╝░░╚═╝  ░░░╚═╝░░░░╚════╝░

██████╗░██╗░░░██╗███████╗░█████╗░██████╗░██╗
██╔══██╗╚██╗░██╔╝██╔════╝██╔══██╗██╔══██╗██║
██████╔╝░╚████╔╝░█████╗░░███████║██████╔╝██║
██╔═══╝░░░╚██╔╝░░██╔══╝░░██╔══██║██╔══██╗╚═╝
██║░░░░░░░░██║░░░██║░░░░░██║░░██║██║░░██║██╗
╚═╝░░░░░░░░╚═╝░░░╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝
            """)
            time.sleep(3)
            ndt=datetime.datetime.now
            print(ndt)

        else:
            print("Password incorrect")
            time.sleep(1000)
        time.sleep(8)
        dvename = str(input("Please enter a device name:"))
        print(dvename)
        time.sleep(1)
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print("                                           ",wd,"                                                         ")
        time.sleep(0.7)
        print("                                         ",tday,"                                              ")
        ndt=datetime.datetime.now
        print("                                        ",ndt,"                                                            ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        print(
            "                                                                                                           ")
        time.sleep(1)    
        print(
            "                                                                                                           ")
        print(
            "                            ....  .     ....   ...  ......                                                    ")
        print(
            "                            .... .  .   ....   .... ......                                                    ")
        print(
            "                            .... .  .   ....   .... ......                                 Notification                   ")
        print(
            "                            .... .  .   ....   .... ......                             Welcome to PyFar!                 ")
        print(
            "                            .... .  .   ....   .... ......                                                    ")
        

        time.sleep(2)
        print("Report problems at the 阿塊 Discord server.")
        time.sleep(2)
        print("Not sponsored by Republic of Gamers.")
        time.sleep(2)
        print("Thank you for choosing PyOSes!")
        time.sleep(0.5)
        print("Credits:")
        time.sleep(0.5)
        print("(nicknames)")
        time.sleep(0.5)
        print("Woody")
        time.sleep(0.5)
        print("Special thanks to:")
        time.sleep(0.5)
        print("My coding teacher for making a Ice Cream idea to change.")
        time.sleep(0.5)
        print("???%")
        time.sleep(0.5)
        print("Helped me fix errors.")
        time.sleep(1)
        print("And everyone I forgot")
        time.sleep(0.5)
        print("Thank you for helping me make this incredible OS!")
        time.sleep(0.5)
        print("Did you read all of this?")
        time.sleep(20)
        break
    elif identity == "usernotfound":
        print("PyFar Error:User@login 404")
        time.sleep(0.5)
        print("UserNotFound")
        time.sleep(1)
        print("User:",username,"not found")
        print("Report problem at the 阿塊 Discord server.")
        time.sleep(5)
        break
    else:
        print("PyFar Error:Expected value")
        print("Report problem at the 阿塊 Discord server.")
        time.sleep(2)
        break